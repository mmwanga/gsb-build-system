# Preserve new configuration files
install_file() {
  NEW="$1"
  OLD="`dirname $NEW`/`basename $NEW .new`"
  # If there's no config file by that name, mv it over:
  if [ ! -r $OLD ]; then
    mv $NEW $OLD
  elif [ "`cat $OLD | md5sum`" = "`cat $NEW | md5sum`" ]; then # toss the redundant copy
    rm $NEW
  fi
  # Otherwise, we leave the .new copy for the admin to consider...
}

install_file etc/speech-dispatcher/speechd.conf.new
install_file etc/speech-dispatcher/clients/emacs.conf.new
install_file etc/speech-dispatcher/clients/orca.conf.new

# Install new info files
if [ -x usr/bin/install-info ]; then
  usr/bin/install-info usr/share/info/spd-say.info usr/info/dir >/dev/null 2>&1
  usr/bin/install-info usr/share/info/speech-dispatcher.info usr/info/dir >/dev/null 2>&1
  usr/bin/install-info usr/share/info/ssip.info usr/info/dir >/dev/null 2>&1
fi
