if [ -x usr/bin/install-info ]; then
  usr/bin/install-info usr/info/liblouis.info.gz usr/info/dir >/dev/null 2>&1
fi
