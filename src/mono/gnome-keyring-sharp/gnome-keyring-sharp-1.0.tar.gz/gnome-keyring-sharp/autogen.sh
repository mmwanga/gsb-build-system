aclocal
automake -a
autoconf
./configure $*
