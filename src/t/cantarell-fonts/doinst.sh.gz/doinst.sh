if [ -x usr/bin/fc-cache ]; then
  chroot . /usr/bin/fc-cache -f 1> /dev/null 2> /dev/null
fi
