#!/bin/sh
/usr/bin/scrollkeeper-update -p /var/lib/scrollkeeper &> /dev/null
