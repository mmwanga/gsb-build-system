if [ -x usr/bin/rarian-sk-rebuild ]; then
  chroot . usr/bin/rarian-sk-update -p /var/lib/rarian --clean-index >/dev/null 2>&1
fi
