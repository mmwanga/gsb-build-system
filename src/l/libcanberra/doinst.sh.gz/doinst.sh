#!/bin/sh

if [ -x usr/bin/update-gtk-immodules ]; then
  usr/bin/update-gtk-immodules
fi
if [ -x usr/bin/update-gtk-immodules-3.0 ]; then
  usr/bin/update-gtk-immodules-3.0
fi
